This file lists the contributors to OpenRefine.

EMERITUS CREATORS (no longer active but honored for bringing OpenRefine to life)
---------------------

 - David Huynh 
 - Stefano Mazzocchi 
 
EMERITUS CONTRIBUTORS (no longer active but honored here for their previous contributions)
---------------------

 - Vishal Talwar 
 - Jeff Fry 
 - Will Moffat 
 - James Home 
 - Heather Campbell 
 
CURRENT CONTRIBUTORS 
--------------------

See up to date list at https://github.com/OpenRefine/OpenRefine/graphs/contributors

 - Iain Sproat 
 - Tom Morris 
 - Thad Guidry 
 - Martin Magdinier 
 - Paul Makepeace 
 - Tomaž Šolc 
 - Gabriel Sjoberg 
 - Rod Salazar 
 - pxb 
 - Qi 
 - Antonin Delpeuch 
 - Owen Stephens 
 - Ettore Rizza 
 - Fabio Tacchelli 
 - noamoss
 - ROMitat
 - Jesus M. Castagnetto
 - Pablo Moyano 
 - David Leoni
 - Cora Johnson-Roberson
 - Pei Long Hui
 - Rudy Alvarez 
 - Mateja Verlic Bruncic
 - nestorjal 
 - Alexey Medvetsky 
 - Remi Rampin 
 - lispc 
 - Bob Harper
 - Felix Lohmeier 
 - Shixiong Zhu
 - Ankit Sardesai
 - Scott Wiedemann
 - Ryo Yamazaki
 - Ralf Claussnitzer
 - Charles Pritchard
 - Maxim Galushka
 - Evelyn Mitchell
 - Andreas Kohn
 - Honza
 - Ram Ezrach 
 - Daniel Berthereau 
 - Gideon Thomas 
 - José Vitor Hisse
 - Vitor Baptista 
 - Joe Wicentowski 
 - mpc9000
 - Dan Michael O. 
 - Adi Eyal
 - Shrubhra Sharma
 - Fadi Maali 
 - Aubrey Mcfato 
 - Matthias Findeisen
 - Mathieu Saby
 - Allan Nordhøy 
 - Tony Opara 
