
                                 OpenRefine for Eclipse
                                 -------------------------
                                 
                        
  This file contains Eclipse-specific help files that can get simplify your life 
  developing OpenRefine with Eclipse (http://www.eclipse.org/).
  
  
  
  Code Style Format Configurations (Refine.style.xml)
  ------------------------------------------------------
  
  This is the code formatting configurations that all OpenRefine developers should follow.
  
  To import, open the Eclipse preferences, then follow to "Java > Code Style > Formatter"
  and click the "Import" button and load the file.  



                                           - o -                                                
  
                                                
   Thank you for your interest.
   
   
                                             The OpenRefine Development Team
                                           http://github.com/OpenRefine/OpenRefine
                                           