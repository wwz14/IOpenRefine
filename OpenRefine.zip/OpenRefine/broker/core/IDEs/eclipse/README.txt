
                                 OpenRefine Helpers for Eclipse
                                 ------------------------------
                                 
                        
  This file contains Eclipse-specific help files that can get simplify your life 
  developing OpenRefine with Eclipse (http://www.eclipse.org/).
  
  
  Launch Files (*.launch)
  -----------------------
  
  These are files that help you running OpenRefine directly from Eclipse without having to execute
  the shell scripts.
  
  To run, right click on the files directly from Eclipse, then do "Run As -> <name>".
  
  NOTE: you have to install the TestNG Eclipse Plugin for the above to work. For more info on how
  to install this plugin, see http://testng.org/doc/eclipse.html


                                           - o -                                                
  
                                                
   Thank you for your interest.
   
   
                                             The OpenRefine Development Team
                                           http://github.com/OpenRefine/OpenRefine
                                           