module commonpart {
    requires slf4j.api;
    requires butterfly;
    requires servlet.api;
    requires json;


    exports com.google.refine.commonpart;
}