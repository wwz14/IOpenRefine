package com.google.refine.sampleExtension;


public class SampleUtil {
    static public int stringArrayLength(String[] a) {
        return a.length;
    }
}
