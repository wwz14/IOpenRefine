/*******************************************************************************
 * MIT License
 * 
 * Copyright (c) 2018 Antonin Delpeuch
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/
package org.openrefine.wikidata.schema;

import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;

import org.jsoup.helper.Validate;
import org.openrefine.wikidata.schema.exceptions.SkipSchemaExpressionException;
import org.wikidata.wdtk.datamodel.helpers.Datamodel;
import org.wikidata.wdtk.datamodel.interfaces.TimeValue;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import com.google.common.collect.ImmutableMap;

/**
 * A constant for a time value, accepting a number of formats which determine
 * the precision of the parsed value.
 * 
 * @author Antonin Delpeuch
 *
 */
public class WbDateConstant implements WbExpression<TimeValue> {

    /**
     * Map of formats accepted by the parser. Each format is associated to the time
     * precision it induces (an integer according to Wikibase's data model).
     */
    public static Map<SimpleDateFormat, Integer> acceptedFormats = ImmutableMap.<SimpleDateFormat, Integer> builder()
            .put(new SimpleDateFormat("yyyy"), 9)
            .put(new SimpleDateFormat("yyyy-MM"), 10)
            .put(new SimpleDateFormat("yyyy-MM-dd"), 11)
            .put(new SimpleDateFormat("yyyy-MM-dd'T'HH"), 12)
            .put(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm"), 13)
            .put(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm'Z'"), 13)
            .put(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"), 14).build();

    private TimeValue parsed;
    private String origDatestamp;

    /**
     * Constructor. Used for deserialization from JSON. The object will be
     * constructed even if the time cannot be parsed (it will evaluate to null) in
     * {@link evaluate}.
     * 
     * @param origDatestamp
     *            the date value as a string
     */
    @JsonCreator
    public WbDateConstant(@JsonProperty("value") String origDatestamp) {
        Validate.notNull(origDatestamp);
        this.setOrigDatestamp(origDatestamp);
    }

    @Override
    public TimeValue evaluate(ExpressionContext ctxt)
            throws SkipSchemaExpressionException {
        return parsed;
    }

    /**
     * Parses a timestamp into a Wikibase {@link TimeValue}. The precision is
     * automatically inferred from the format.
     * 
     * @param datestamp
     *            the time to parse
     * @return
     * @throws ParseException
     *             if the time cannot be parsed
     */
    public static TimeValue parse(String datestamp)
            throws ParseException {
        Date date = null;
        int precision = 9; // default precision (will be overridden)
        for (Entry<SimpleDateFormat, Integer> entry : acceptedFormats.entrySet()) {
            ParsePosition position = new ParsePosition(0);
            String trimmedDatestamp = datestamp.trim();
            date = entry.getKey().parse(trimmedDatestamp, position);

            // Ignore parses which failed or do not consume all the input
            if (date != null && position.getIndex() == trimmedDatestamp.length()) {
                precision = entry.getValue();
                break;
            }
        }
        if (date == null) {
            throw new ParseException("Invalid date.", 0);
        } else {
            Calendar calendar = Calendar.getInstance();
            calendar = Calendar.getInstance();
            calendar.setTime(date);
            return Datamodel.makeTimeValue(calendar.get(Calendar.YEAR), (byte) (calendar.get(Calendar.MONTH) + 1), 
                    (byte) calendar.get(Calendar.DAY_OF_MONTH), (byte) calendar.get(Calendar.HOUR_OF_DAY),
                    (byte) calendar.get(Calendar.MINUTE), (byte) calendar.get(Calendar.SECOND), (byte) precision, 0, 0,
                    0, TimeValue.CM_GREGORIAN_PRO);
        }
    }

    /**
     * @return the original datestamp
     */
    @JsonProperty("value")
    public String getOrigDatestamp() {
        return origDatestamp;
    }

    private void setOrigDatestamp(String origDatestamp) {
        this.origDatestamp = origDatestamp;
        try {
            this.parsed = parse(origDatestamp);
        } catch (ParseException e) {
            throw new IllegalArgumentException("Invalid datestamp provided: " + origDatestamp);
        }
    }

    @Override
    public boolean equals(Object other) {
        if (other == null || !WbDateConstant.class.isInstance(other)) {
            return false;
        }
        WbDateConstant otherConstant = (WbDateConstant) other;
        return origDatestamp.equals(otherConstant.getOrigDatestamp());
    }

    @Override
    public int hashCode() {
        return origDatestamp.hashCode();
    }

}
