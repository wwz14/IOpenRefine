
                                 Google Refine Helpers for Eclipse
                                 ---------------------------------
                                 
                        
  This file contains Eclipse-specific help files that can get simplify your life 
  developing Google Refine with Eclipse (http://www.eclipse.org/).
  
  
  Launch Files (*.launch)
  -----------------------
  
  These are files that help you running Google Refine directly from eclipse without having to execute
  the shell scripts.
  
  To run, right click on the files directly from Eclipse, then do "Run As -> <name>".
  
  
  
  Code Style Format Configurations (Refine.style.xml)
  ------------------------------------------------------
  
  This is the code formatting configurations that all Google Refine developers should follow.
  
  To import, open the Eclipse preferences, then follow to "Java > Code Style > Formatter"
  and click the "Import" button and load the file.  



                                           - o -                                                
  
                                                
   Thank you for your interest.
   
   
                                             The Google Refine Development Team
                                           http://code.google.com/p/google-refine/
                                           